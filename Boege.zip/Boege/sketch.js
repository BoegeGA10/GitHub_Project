var x = [10, 20];

var x2 = [];

var x3 = [];

var y = [];

var num = 60;

function setup() {

	createCanvas(400, 400);

	print(x.length);

	for (var i = 0; i < 3000; i++) {
		x2[i] = random(-1000, 200);
	}

	for (var i =0; i < num; i++) {
		x3[i] = 0;
		y[i] = 0;
	}

}

function draw() {
	background(0);

	for (var i = 0; i < x2.length; i++) {
		x2[i] +=0.5;
		var y = i * 0.4;
		ellipse(x2[i], y, 3, 3);
	}

	for (var i = num-1; i > 0; i--) {
		x3[i] = x3[i-1];
		y[i] = y[i-1];
	}

	x3[0] = mouseX;
	y[0] = mouseY;

	for (var i = 0; i < num; i++) {
		fill(i * 4);
		ellipse(x3[i], y[i], 40, 40);
	}

	rect(385, 18, 15, 5);
	triangle(367, 20, 379, 10, 379, 30);
	triangle(375, 20, 387, 10, 387, 30);

	rect(370, 37, 30, 7);
	triangle(351, 40, 363, 30, 363, 50);
	triangle(359, 40, 371, 30, 371, 50);
	triangle(367, 40, 379, 30, 379, 50);

	rect(385, 58, 15, 5);
	triangle(367, 60, 379, 50, 379, 70);
	triangle(375, 60, 387, 50, 387, 70);

	rect(385, 98, 15, 5);
	triangle(367, 100, 379, 90, 379, 110);
	triangle(375, 100, 387, 90, 387, 110);

	rect(370, 117, 30, 7);
    triangle(351, 120, 363, 110, 363, 130);
    triangle(359, 120, 371, 110, 371, 130);
    triangle(367, 120, 379, 110, 379, 130);

    rect(390, 158, 10, 4);
    triangle(381, 160, 391, 152, 391, 168);

	rect(385, 198, 15, 5);
	triangle(367, 200, 379, 190, 379, 210);
	triangle(375, 200, 387, 190, 387, 210);

	rect(385, 218, 15, 5);
	triangle(367, 220, 379, 210, 379, 230);
	triangle(375, 220, 387, 210, 387, 230);

	rect(370, 227, 30, 7);
	triangle(351, 230, 363, 220, 363, 240);
	triangle(359, 230, 371, 220, 371, 240);
	triangle(367, 230, 379, 220, 379, 240);

	rect(390, 238, 10, 4);
	triangle(381, 240, 391, 232, 391, 248);

	rect(385, 348, 15, 5);
	triangle(367, 350, 379, 340, 379, 360);
	triangle(375, 350, 387, 340, 387, 360);

	rect(370, 357, 30, 7);
	triangle(351, 360, 363, 350, 363, 370);
	triangle(359, 360, 371, 350, 371, 370);
	triangle(367, 360, 379, 350, 379, 370);

	rect(390, 378, 10, 4);
	triangle(381, 380, 391, 372, 391, 388);

	rect(350, 270, 50, 40);
	triangle(330, 290, 355, 260, 355, 320);

	ellipse(60, 50, 70, 70);
}
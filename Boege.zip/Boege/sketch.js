var img1;
var img2;
var img3;

function preload() {

	img1 = loadImage("GTR.jpg");
	img2 = loadImage("Landscape.jpg");
	img3 = loadImage("clouds.png");
}

function setup() {

	createCanvas(1100, 500);
	textFont("Dela Gothic One");

}

function draw() {

	image(img1, 0, 0);
	image(img2, 600, 0);

	image(img1, 0, 0, mouseX * 2, mouseY * 2);

	image(img3, 0, mouseY * -1);

	textSize(32);
	text("I am Iron Man", 700, 60);
	fill(0);
	stroke(255);

}
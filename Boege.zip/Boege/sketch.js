function setup() {
  // put setup code here
  createCanvas(400, 400);
}

function draw() {
    // put drawing code here
    background(204);

    strokeWeight(4);
    stroke(51);
    fill(51);
    ellipse(40, 40, 60, 60);

    strokeWeight(4);
    stroke(51);
    fill(51);
    point(380, 20);

    strokeWeight(10);
    strokeCap(ROUND);
    stroke(51);
    fill(51);
    line(40, 180, 220, 360);

    strokeWeight(4);
    stroke(51);
    fill(51);
    rect(100, 80, 160, 60);

    noFill();
    rect(305, 110, 55, 155);

}
